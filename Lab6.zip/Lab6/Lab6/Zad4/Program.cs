﻿using System;
using System.IO;
using System.Linq;
using System.Text.Json;

class Program
{
    static void Main()
    {
        Console.Write("Podaj nazwę pliku z bazą danych: ");
        string nazwaPliku = Console.ReadLine();

        try
        {
            string json = File.ReadAllText(nazwaPliku);
            BazaDanychPopulacji baza = JsonSerializer.Deserialize<BazaDanychPopulacji>(json);
            int rok1 = 1970;
            int rok2 = 2000;
            string kraj = "Indie";

            int roznicaPopulacji = SprawdzRoznicePopulacji(baza, rok1, rok2, kraj);

            Console.WriteLine($"Różnica populacji między rokiem {rok1} a {rok2} dla {kraj}: {roznicaPopulacji}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Wystąpił błąd: {ex.Message}");
        }
    }

    static int SprawdzRoznicePopulacji(BazaDanychPopulacji baza, int rok1, int rok2, string kraj)
    {
        if (baza.Kraje.ContainsKey(kraj) && baza.Kraje[kraj].ContainsKey(rok1) && baza.Kraje[kraj].ContainsKey(rok2))
        {
            int populacjaRok1 = baza.Kraje[kraj][rok1];
            int populacjaRok2 = baza.Kraje[kraj][rok2];
            return populacjaRok2 - populacjaRok1;
        }

        return 0;
    }
}

class BazaDanychPopulacji
{
    public Dictionary<string, Dictionary<int, int>> Kraje { get; set; }
}

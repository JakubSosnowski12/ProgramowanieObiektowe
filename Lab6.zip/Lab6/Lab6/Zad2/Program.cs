﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.Write("Podaj nazwę pliku do wczytania: ");
        string nazwaPliku = Console.ReadLine();

        try
        {
            string zawartoscPliku = File.ReadAllText(nazwaPliku);
            Console.WriteLine($"Zawartość pliku {nazwaPliku}:\n{zawartoscPliku}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Wystąpił błąd: {ex.Message}");
        }
    }
}

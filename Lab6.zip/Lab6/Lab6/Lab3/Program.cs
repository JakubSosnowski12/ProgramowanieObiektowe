﻿using System;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.Write("Podaj nazwę pliku z peselami: ");
        string nazwaPliku = Console.ReadLine();

        try
        {
            string[] pesels = File.ReadAllLines(nazwaPliku);
            int iloscZenskichPeseli = SprawdzIloscZenskichPeseli(pesels);

            Console.WriteLine($"Ilość żeńskich peseli: {iloscZenskichPeseli}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Wystąpił błąd: {ex.Message}");
        }
    }

    static int SprawdzIloscZenskichPeseli(string[] pesels)
    {
        return pesels.Count(pesel => int.Parse(pesel.Substring(9, 1)) % 2 == 0);
    }
}

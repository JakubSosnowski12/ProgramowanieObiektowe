﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.Write("Podaj numer albumu: ");
        string numerAlbumu = Console.ReadLine();

        Console.Write("Podaj nazwę pliku do zapisu: ");
        string nazwaPliku = Console.ReadLine();

        try
        {
            File.WriteAllText(nazwaPliku, numerAlbumu);
            Console.WriteLine($"Numer albumu został zapisany do pliku {nazwaPliku}.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Wystąpił błąd: {ex.Message}");
        }
    }
}

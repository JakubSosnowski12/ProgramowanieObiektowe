﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laby
{
    internal class Reader : Person
    {
        public Book[] Books { get; set; }
        public Reader(string firstname, string lastname, int age):base(firstname, lastname, age)
        {

        }
        public void ViewBook()
        {
            base.View1();
            Console.WriteLine($"\n przeczytał poniższe książki: ");
            foreach (Book book in Books)
            {
                Console.WriteLine(book.Title);
            }
        }
    }
}

﻿using laby;

Person[] people = new Person[]
{
    new Person("Jan", "Nowak", 18),
     new Person("Jan", "Dąbrowski", 19),
      new Person("Jan", "Dąb", 20),
       new Person("Jan", "Michalski", 21),
};
Book[] books = new Book[]
{
 new Book("Tytuł 1", people[0], new DateTime(2023,11,26)),
  new Book("Tytuł 2", people[1], new DateTime(2024,11,26)),
   new Book("Tytuł 3", people[2], new DateTime(2025,11,26)),
};
Reader[] readers = new Reader[people.Length];
for(int i = 0; i< readers.Length; i++)
{
    readers[i] = new Reader(people[i].Firstname, people[i].Lastname, people[i].Age);
    if (i == 0)
        readers[i].Books = new Book[]
        {
            books[randInt()]

        };
    else if (i == 1)
        readers[i].Books = new Book[]
        {
            books[randInt()],
            books[randInt()],
        };
    else if (i == 2)
        readers[i].Books = new Book[]
        {
            books[randInt()],
            books[randInt()],
            books[randInt()],
        };

}
foreach(var item in readers)
{
    item.ViewBook();
}
int randInt()
{
    Random random = new Random();
    return random.Next(books.Length);
}
foreach(Book item in books)
{
    item.View();
}
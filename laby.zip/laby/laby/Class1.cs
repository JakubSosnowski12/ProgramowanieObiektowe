﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laby
{
    internal class Person
    {
        private string firstname;
        private string lastname;
        private int age;
        public string Firstname { get { return firstname;} set { firstname = value; } }
        public string Lastname { get { return lastname;} set { lastname = value; } }    
        public int Age { get { return age;} set { age = value; } }

        public Person(string firstname, string lastname, int age)
        {
            Firstname = firstname;
            Lastname = lastname;
            Age = age;
        }
        public void View()
        {
            Console.WriteLine($": Imie: {firstname}, Nazwisko: {lastname}, Wiek: {age}");
        }
        public void View1()
        {
            Console.WriteLine($": Imie: {firstname}, Nazwisko: {lastname}");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laby
{
    internal class Book
    {
        private string title;
        Person author;
        DateTime releaseDate;
        public string Title { get { return title; } set { } }

        public Book(string title, Person author, DateTime releaseDate)
        {
            this.author = author;
            this.releaseDate = releaseDate;
            this.title = title;
        }
        public void View()
        {
            Console.WriteLine($"Tytul: {Title}\t");
            author.View();
            Console.WriteLine($"DataWydania: {releaseDate.ToShortDateString()}");
        }

    }
}

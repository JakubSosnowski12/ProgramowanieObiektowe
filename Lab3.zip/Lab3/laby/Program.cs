﻿using laby;

Person[] people = new Person[]
{
    new Person("Jan", "Nowak", 18),
     new Person("Jan", "Dąbrowski", 19),
      new Person("Jan", "Dąb", 20),
       new Person("Jan", "Michalski", 21),
};
Book[] books = new Book[]
{
 new Book("Tytuł 1", people[0], new DateTime(2023,11,26)),
  new Book("Tytuł 2", people[1], new DateTime(2024,11,26)),
   new Book("Tytuł 3", people[2], new DateTime(2025,11,26)),
   new Book("Tytuł 4", people[3], new DateTime(2026,11,26)),
   new Book("Tytuł 4", people[3], new DateTime(2027,11,26)),
};
Reader[] readers = new Reader[people.Length];
for(int i = 0; i< readers.Length; i++)
{
    readers[i] = new Reader(people[i].Firstname, people[i].Lastname, people[i].Age);
    if (i == 0)
        readers[i].Books = new Book[]
        {
            books[randInt()]

        };
    else if (i == 1)
        readers[i].Books = new Book[]
        {
            books[randInt()],
            books[randInt()],
        };
    else if (i == 2)
        readers[i].Books = new Book[]
        {
            books[randInt()],
            books[randInt()],
            books[randInt()],
        };

}
foreach(var item in readers)
{
    item.View();
}
int randInt()
{
    Random random = new Random();
    return random.Next(books.Length);
}
foreach(Book item in books)
{
    item.View();
}
Reviewer reviewer1 = new Reviewer("Adam", "Kowalski", 30);
Reviewer reviewer2 = new Reviewer("Anna", "Nowak", 28);

// Przypisanie książek
reviewer1.Books = new Book[]
{
    books[0], 
};

if (books.Length > 3)
{
    reviewer2.Books = new Book[]
    {
        books[2], 
        books[3]  
    };
}
else
{
    Console.WriteLine("Nie wystarczająca liczba książek w tablicy books.");
}
// Ocena książek przez recenzentów
Console.WriteLine("Recenzent 1:");
reviewer1.RateBooks();

Console.WriteLine("\nRecenzent 2:");
reviewer2.RateBooks();

List<Person> peopleList = new List<Person>();

Reader newReader = new Reader("Adam", "Kowalski", 25);
Reviewer newReviewer = new Reviewer("Anna", "Nowak", 30);

// Przypisanie książek do nowych czytelników i recenzentów
if (books.Length > 1)
{
    newReader.Books = new Book[]
    {
        books[books.Length - 1],
        books[books.Length - 2]  
    };
}

if (books.Length > 3)
{
    newReviewer.Books = new Book[]
    {
        books[books.Length - 3],
        books[books.Length - 4]
    };
}

// Dodawanie czytelnika i recenzenta do listy
peopleList.Add(newReader);
peopleList.Add(newReviewer);

// Wywołanie metody View na wszystkich obiektach z listy
foreach (var person in peopleList)
{
    person.View();
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laby
{
    internal class Reviewer : Reader
    {
        private readonly Random random;

        public Reviewer(string firstname, string lastname, int age) : base(firstname, lastname, age)
        {
            random = new Random();
        }

        public void RateBooks()
        {
            foreach (Book book in Books)
            {
                int rating = random.Next(1, 6); // Losowa ocena od 1 do 5
                Console.WriteLine($"Tytuł: {book.Title}, Ocena: {rating}");
            }
        }
    }
}

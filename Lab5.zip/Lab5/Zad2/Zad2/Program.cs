﻿using System;

class Program
{
    static void Main()
    {
        for (int i = 0; i < 5; i++)
        {
            try
            {
                LosowyWyjatek();
            }
            catch (WyjatekA)
            {
                Console.WriteLine("Złapano Wyjatek A");
            }
            catch (WyjatekB)
            {
                Console.WriteLine("Złapano Wyjatek B");
            }
            catch (WyjatekC)
            {
                Console.WriteLine("Złapano Wyjatek C");
            }
        }
    }

    static void LosowyWyjatek()
    {
        Random random = new Random();
        int losowaLiczba = random.Next(1, 4);

        switch (losowaLiczba)
        {
            case 1:
                throw new WyjatekA("To jest Wyjatek A.");
            case 2:
                throw new WyjatekB("To jest Wyjatek B.");
            case 3:
                throw new WyjatekC("To jest Wyjatek C.");
        }
    }
}

class WyjatekA : Exception
{
    public WyjatekA(string message) : base(message) { }
}

class WyjatekB : Exception
{
    public WyjatekB(string message) : base(message) { }
}

class WyjatekC : Exception
{
    public WyjatekC(string message) : base(message) { }
}

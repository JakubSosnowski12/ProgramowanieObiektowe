﻿using System;

class Program
{
    static void Main()
    {
        try
        {
            WypiszDlugoscNapisu(null);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Obsługiwany wyjątek: " + ex.Message);
            Console.WriteLine("StackTrace: " + ex.StackTrace);

            // Dodaj wyjątek jako przyczynę nowego wyjątku
            throw new Exception("Nowy wyjątek z przyczyną", ex);
        }
    }

    static void WypiszDlugoscNapisu(string napis)
    {
        if (napis == null)
        {
            throw new ArgumentNullException(nameof(napis), "Napis nie może być null.");
        }

        Console.WriteLine("Długość napisu: " + napis.Length);
    }
}
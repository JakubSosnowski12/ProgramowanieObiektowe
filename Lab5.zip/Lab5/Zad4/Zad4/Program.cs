﻿using System;
using System.IO;
using System.Text.Json;

public class DeepCopy
{
    public static T Copy<T>(T obj) where T : class
    {
        if (obj == null)
        {
            throw new ArgumentNullException(nameof(obj), "Obiekt nie może być null.");
        }

        string jsonString = JsonSerializer.Serialize(obj);

        return JsonSerializer.Deserialize<T>(jsonString);
    }
}

class Program
{
    static void Main()
    {
        Person originalPerson = new Person("John", 25);
        Person copiedPerson = DeepCopy.Copy(originalPerson);

        Console.WriteLine("Oryginalna osoba: " + originalPerson);
        Console.WriteLine("Skopiowana osoba: " + copiedPerson);
    }
}

public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }

    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public override string ToString()
    {
        return $"Name: {Name}, Age: {Age}";
    }
}

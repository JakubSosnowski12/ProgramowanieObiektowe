﻿using System;

public interface IClonable<T>
{
    T Clone();
}

public class Person : IClonable<Person>, ICloneable
{
    public string Name { get; set; }
    public int Age { get; set; }

    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public Person Clone()
    {
        return (Person)MemberwiseClone();
    }

    object ICloneable.Clone()
    {
        return Clone();
    }

    public override string ToString()
    {
        return $"Name: {Name}, Age: {Age}";
    }
}

class Program
{
    static void Main()
    {
        Person originalPerson = new Person("John", 25);

        Person clonedPerson = originalPerson.Clone();

        Console.WriteLine("Oryginalna osoba: " + originalPerson);
        Console.WriteLine("Skopiowana osoba (IClonable): " + clonedPerson);

        Person memberwiseClonedPerson = (Person)originalPerson.Clone();

        Console.WriteLine("Skopiowana osoba (MemberwiseClone): " + memberwiseClonedPerson);
    }
}

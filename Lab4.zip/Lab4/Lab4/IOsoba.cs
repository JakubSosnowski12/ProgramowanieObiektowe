﻿namespace Lab4
{
    public interface IOsoba
    {
        string Imie { get; set; }
        string Nazwisko { get; set; }
        void ZwrocPelnaNazwe();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    public class Osoba
    {
        public string Imie {  get; set; }   
        public string Nazwisko { get; set;}

        public string Pesel { get; set; }

        public Osoba(string imie, string nazwisko, string pesel)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Pesel = pesel;
        }
        public virtual void WyswietlInformacje()
        {
            Console.WriteLine($"Imię: {Imie}");
            Console.WriteLine($"Nazwisko: {Nazwisko}");
            Console.WriteLine($"PESEL: {Pesel}");
        }
        public void SetFirstName(string firstName)
        {
            this.Imie = firstName;
        }
        public void SetLastName(string lastName)
        {
            this.Nazwisko = lastName;
        }
        public void SetPesel(string pesel)
        {
            this.Pesel = pesel;
        }

        public int GetAge()
        {

            return 22;
        }
        public virtual string Info()
        {
            int wiek = GetAge();
            return $"Osoba {GetFullName()}, wiek: {wiek}";
        }


        public string GetGender()
        {
            int pozycja = int.Parse(Pesel.Substring(9, 1));
            if (pozycja % 2 == 0)
                return "Kobieta";
            else
                return "Mężczyzna";
        }
        public string GetEducationalInfo()
        {
            int wiek = GetAge();

            if(wiek < 15)
            {
                return "Szkoła podstawowa";
            } 
            else if (wiek >15 && wiek <= 20)
            {
                return "Szkoła średnia";
            }
            else
            {
                return "Studia";
            }
        }
        public string GetFullName()
        {
            return $"{Imie} {Nazwisko}";
        }
        public bool CanGoAloneToHome()
        {
            bool flag = false;
            int age = GetAge();
            if(age < 13)
            {
                return flag;
            }
            else
            {
                return !flag;
            }
        }
    }
}

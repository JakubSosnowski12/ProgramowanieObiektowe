﻿namespace Lab4
{
    public static class Rozszerz
    {
        public static void WypiszOsoby(this List<IOsoba> lista)
        {
            foreach (var osoba in lista)
            {
                Console.WriteLine($"{osoba.Imie} {osoba.Nazwisko}");
            }
        }

        public static void PosortujOsobyPoNazwisku(this List<IOsoba> lista)
        {
            lista.Sort((os1, os2) => os1.Nazwisko.CompareTo(os2.Nazwisko));
        }
    }
}
﻿namespace Lab4
{
    public class StudentWSIiZ : Student
    {
        public new string WypiszPelnaNazweIUczelnie()
        {
            return base.WypiszPelnaNazweIUczelnie() + " WSIiZ";
        }
    }
}

﻿using Lab4;

class Program
{
    static void Main()
    {
        List<IOsoba> listaOsob = new List<IOsoba>();

        Student student1 = new Student
        {
            Imie = "Jan",
            Nazwisko = "Kowalski",
            Uczelnia = "Politechnika",
            Kierunek = "Informatyka",
            Rok = 2,
            Semestr = 3
        };

        Student student2 = new Student
        {
            Imie = "Anna",
            Nazwisko = "Nowak",
            Uczelnia = "Uniwersytet",
            Kierunek = "Psychologia",
            Rok = 1,
            Semestr = 2
        };

        StudentWSIiZ studentWSIiZ = new StudentWSIiZ
        {
            Imie = "Piotr",
            Nazwisko = "Wiśniewski",
            Uczelnia = "WSIiZ",
            Kierunek = "Biznes",
            Rok = 3,
            Semestr = 5
        };

        listaOsob.Add(student1);
        listaOsob.Add(student2);
        listaOsob.Add(studentWSIiZ);

        Console.WriteLine("Lista osób:");
        listaOsob.WypiszOsoby();

        Console.WriteLine("\nPosortowana lista osób po nazwisku:");
        listaOsob.PosortujOsobyPoNazwisku();
        listaOsob.WypiszOsoby();

        Console.WriteLine("\nPełna informacja o studentach:");
        foreach (var osoba in listaOsob)
        {
            if (osoba is IStudent student)
            {
                Console.WriteLine(student.WypiszPelnaNazweIUczelnie());
            }
        }
    }
}
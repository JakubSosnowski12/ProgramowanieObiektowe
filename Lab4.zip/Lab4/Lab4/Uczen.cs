﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    public class Uczen : Osoba
    {

        public string Szkola { get; set; }
        public bool MozeSamWracacDoDomu { get; set; }

        public Uczen(string i, string n, string p) : base(i, n, p)
        {
            this.Szkola = string.Empty;
            this.MozeSamWracacDoDomu = true;
        }
        public void SetSchool(string szkola)
        {
            Szkola = szkola;
        }

        public void ChangeSchool(string nowaSzkola)
        {
            Szkola = nowaSzkola;
        }

        public void SetCanGoHomeAlone(bool mozeSamWracac)
        {
            MozeSamWracacDoDomu = mozeSamWracac;
        }
        public override string Info()
        {
            int wiek = GetAge();

            if (wiek < 12 && !MozeSamWracacDoDomu)
            {
                return $"Uczeń {GetFullName()}, wiek: {wiek}, nie może sam wracać do domu.";
            }
            else
            {
                return $"Uczeń {GetFullName()}, wiek: {wiek}, może sam wracać do domu.";
            }
        }
    }
}

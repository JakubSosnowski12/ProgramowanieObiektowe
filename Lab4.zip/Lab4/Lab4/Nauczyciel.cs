﻿using Lab4;

public class Nauczyciel : Uczen
{
    protected string TytulNaukowy;
    protected List<Uczen> PodwladniUczniowie;

    public Nauczyciel(string imie, string nazwisko, string pesel) : base(imie, nazwisko, pesel)
    {
        PodwladniUczniowie = new List<Uczen>();
    }

    public void AddStudent(Uczen uczen)
    {
        PodwladniUczniowie.Add(uczen);
    }

    public void RemoveStudent(Uczen uczen)
    {
        PodwladniUczniowie?.Remove(uczen);
    }

    public void WhichStudentCanGoHomeAlone(DateTime dateToCheck)
    {
        Console.WriteLine($"Uczniowie, którzy mogą iść sami do domu w dniu {dateToCheck}:");
        foreach (var uczen in PodwladniUczniowie)
        {
            if (uczen.MozeSamWracacDoDomu && uczen.GetAge() >= 12)
            {
                Console.WriteLine($"{uczen.GetFullName()}");
            }
        }
    }
}
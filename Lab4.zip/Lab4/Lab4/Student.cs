﻿using Lab4;

public class Student : IStudent
{
    public string Imie { get; set; }
    public string Nazwisko { get; set; }
    public string Uczelnia { get; set; }
    public string Kierunek { get; set; }
    public int Rok { get; set; }
    public int Semestr { get; set; }

    public void ZwrocPelnaNazwe()
    {
        Console.WriteLine($"{Imie} {Nazwisko}");
    }

    public string WypiszPelnaNazweIUczelnie()
    {
        return $"{Imie} {Nazwisko} – {Semestr} sem. {Rok} {Kierunek} {Uczelnia}";
    }
}

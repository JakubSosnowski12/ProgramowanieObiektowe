﻿using System;

class Calculator
{
    static void Main()
    {
        while (true)
        {
            Console.WriteLine("Kalkulator matematyczny:");
            Console.WriteLine("1. Oblicz sumę");
            Console.WriteLine("2. Oblicz różnicę");
            Console.WriteLine("3. Oblicz iloczyn");
            Console.WriteLine("4. Oblicz iloraz");
            Console.WriteLine("5. Oblicz potęgę");
            Console.WriteLine("6. Oblicz pierwiastek");
            Console.WriteLine("7. Oblicz wartość sinusa");
            Console.WriteLine("8. Oblicz wartość cosinusa");
            Console.WriteLine("9. Oblicz wartość tangensa");
            Console.WriteLine("10. Zakończ program");
            Console.Write("Wybierz operację (1-10): ");

            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                switch (choice)
                {
                    case 1:
                        Console.Write("Podaj pierwszą liczbę: ");
                        double num1 = double.Parse(Console.ReadLine());
                        Console.Write("Podaj drugą liczbę: ");
                        double num2 = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Suma: {num1 + num2}");
                        break;
                    case 2:
                        Console.Write("Podaj pierwszą liczbę: ");
                        num1 = double.Parse(Console.ReadLine());
                        Console.Write("Podaj drugą liczbę: ");
                        num2 = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Różnica: {num1 - num2}");
                        break;
                    case 3:
                        Console.Write("Podaj pierwszą liczbę: ");
                        num1 = double.Parse(Console.ReadLine());
                        Console.Write("Podaj drugą liczbę: ");
                        num2 = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Iloczyn: {num1 * num2}");
                        break;
                    case 4:
                        Console.Write("Podaj pierwszą liczbę: ");
                        num1 = double.Parse(Console.ReadLine());
                        Console.Write("Podaj drugą liczbę: ");
                        num2 = double.Parse(Console.ReadLine());
                        if (num2 != 0)
                            Console.WriteLine($"Iloraz: {num1 / num2}");
                        else
                            Console.WriteLine("Dzielenie przez zero!");
                        break;
                    case 5:
                        Console.Write("Podaj liczbę: ");
                        num1 = double.Parse(Console.ReadLine());
                        Console.Write("Podaj wykładnik potęgi: ");
                        num2 = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Potęga: {Math.Pow(num1, num2)}");
                        break;
                    case 6:
                        Console.Write("Podaj liczbę: ");
                        num1 = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Pierwiastek: {Math.Sqrt(num1)}");
                        break;
                    case 7:
                        Console.Write("Podaj kąt w radianach: ");
                        double angle = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Sinus({angle}): {Math.Sin(angle)}");
                        break;
                    case 8:
                        Console.Write("Podaj kąt w radianach: ");
                        angle = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Cosinus({angle}): {Math.Cos(angle)}");
                        break;
                    case 9:
                        Console.Write("Podaj kąt w radianach: ");
                        angle = double.Parse(Console.ReadLine());
                        Console.WriteLine($"Tangens({angle}): {Math.Tan(angle)}");
                        break;
                    case 10:
                        Console.WriteLine("Koniec programu.");
                        return;
                    default:
                        Console.WriteLine("Niepoprawny wybór operacji.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Niepoprawny wybór operacji.");
            }

            Console.WriteLine();
        }
    }
}

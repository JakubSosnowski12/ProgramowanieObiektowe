﻿using System;

class Program
{
    static void Main()
    {
        double[] tablica = new double[10];

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Podaj liczbę {i + 1}: ");
            tablica[i] = double.Parse(Console.ReadLine());
        }

        Console.WriteLine("Tablica od pierwszego do ostatniego indeksu:");
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine(tablica[i]);
        }

        Console.WriteLine("Tablica od ostatniego do pierwszego indeksu:");
        for (int i = 9; i >= 0; i--)
        {
            Console.WriteLine(tablica[i]);
        }

        Console.WriteLine("Elementy o parzystych indeksach:");
        for (int i = 1; i < 10; i += 2)
        {
            Console.WriteLine(tablica[i]);
        }

        Console.WriteLine("Elementy o nieparzystych indeksach:");
        for (int i = 0; i < 10; i += 2)
        {
            Console.WriteLine(tablica[i]);
        }
    }
}

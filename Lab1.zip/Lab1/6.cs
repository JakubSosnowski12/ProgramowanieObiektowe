﻿using System;

class Infinite
{
    static void Main()
    {
        while (true)
        {
            Console.Write("Wprowadź liczbę całkowitą (lub liczbę mniejszą od zera, aby zakończyć): ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                if (number < 0)
                {
                    break;
                }
            }
            else
            {
                Console.WriteLine("To nie jest liczba całkowita. Spróbuj ponownie.");
            }
        }
    }
}

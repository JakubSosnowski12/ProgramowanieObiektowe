﻿using System;

class Delta
{
    static void Main()
    {
        Console.WriteLine("Obliczanie wyróżnika delta i pierwiastków trójmianu kwadratowego (ax^2 + bx + c = 0)");

        Console.Write("Podaj współczynnik a: ");
        if (double.TryParse(Console.ReadLine(), out double a))
        {
            Console.Write("Podaj współczynnik b: ");
            if (double.TryParse(Console.ReadLine(), out double b))
            {
                Console.Write("Podaj współczynnik c: ");
                if (double.TryParse(Console.ReadLine(), out double c))
                {
                    double delta = b * b - 4 * a * c;

                    Console.WriteLine($"Wyróżnik delta: {delta}");

                    if (delta > 0)
                    {
                        double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                        double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                        Console.WriteLine($"Pierwiastki: x1 = {x1}, x2 = {x2}");
                    }
                    else if (delta == 0)
                    {
                        double x = -b / (2 * a);
                        Console.WriteLine($"Pierwiastek podwójny: x = {x}");
                    }
                    else
                    {
                        Console.WriteLine("Trójmian nie ma pierwiastków rzeczywistych.");
                    }
                }
                else
                {
                    Console.WriteLine("Niepoprawny współczynnik c. Wprowadź liczbę.");
                }
            }
            else
            {
                Console.WriteLine("Niepoprawny współczynnik b. Wprowadź liczbę.");
            }
        }
        else
        {
            Console.WriteLine("Niepoprawny współczynnik a. Wprowadź liczbę.");
        }
    }
}

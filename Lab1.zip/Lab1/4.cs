﻿using System;

class TenNumbers
{
    static void Main()
    {
        double[] numbers = new double[10];

        Console.WriteLine("Wprowadź 10 liczb:");

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Liczba {i + 1}: ");
            if (double.TryParse(Console.ReadLine(), out double number))
            {
                numbers[i] = number;
            }
            else
            {
                Console.WriteLine("To nie jest prawidłowa liczba. Spróbuj ponownie.");
                i--;
            }
        }

        Console.WriteLine("Wybierz operację:");
        Console.WriteLine("1. Oblicz sumę elementów tablicy");
        Console.WriteLine("2. Oblicz iloczyn elementów tablicy");
        Console.WriteLine("3. Wyznacz wartość średnią");
        Console.WriteLine("4. Wyznacz wartość minimalną");
        Console.WriteLine("5. Wyznacz wartość maksymalną");

        int choice;
        if (int.TryParse(Console.ReadLine(), out choice))
        {
            switch (choice)
            {
                case 1:
                    double sum = 0;
                    foreach (double num in numbers)
                    {
                        sum += num;
                    }
                    Console.WriteLine($"Suma elementów: {sum}");
                    break;
                case 2:
                    double product = 1;
                    foreach (double num in numbers)
                    {
                        product *= num;
                    }
                    Console.WriteLine($"Iloczyn elementów: {product}");
                    break;
                case 3:
                    double average = 0;
                    foreach (double num in numbers)
                    {
                        average += num;
                    }
                    average /= numbers.Length;
                    Console.WriteLine($"Wartość średnia: {average}");
                    break;
                case 4:
                    double min = numbers[0];
                    foreach (double num in numbers)
                    {
                        if (num < min)
                        {
                            min = num;
                        }
                    }
                    Console.WriteLine($"Wartość minimalna: {min}");
                    break;
                case 5:
                    double max = numbers[0];
                    foreach (double num in numbers)
                    {
                        if (num > max)
                        {
                            max = num;
                        }
                    }
                    Console.WriteLine($"Wartość maksymalna: {max}");
                    break;
                default:
                    Console.WriteLine("Niepoprawny wybór operacji.");
                    break;
            }
        }
        else
        {
            Console.WriteLine("Niepoprawny wybór operacji.");
        }
    }
}

﻿using System;
using System.Numerics;

class Liczba
{
    private int[] cyfry;

    public Liczba(string wartosc)
    {
        UstawLiczbe(wartosc);
    }

    public void UstawLiczbe(string wartosc)
    {
        cyfry = new int[wartosc.Length];

        for (int i = 0; i < wartosc.Length; i++)
        {
            cyfry[i] = wartosc[i] - '0';
        }
    }

    public void WypiszLiczbe()
    {
        foreach (int cyfra in cyfry)
        {
            Console.Write(cyfra);
        }
        Console.WriteLine();
    }

    public void PomnozPrzezInt(int mnoznik)
    {
        BigInteger wynik = BigInteger.Parse(string.Join("", cyfry)) * mnoznik;
        UstawLiczbe(wynik.ToString());
    }

    public BigInteger Silnia(int n)
    {
        BigInteger wynik = 1;
        for (int i = 1; i <= n; i++)
        {
            wynik *= i;
        }
        return wynik;
    }
}

﻿using System;

class MojaData
{
    private DateTime biezacaData;

    public MojaData()
    {
        biezacaData = DateTime.Now;
    }

    public DateTime OdczytajBiezacaDate()
    {
        return biezacaData;
    }

    public void PrzesunDoPrzoduOTydzien()
    {
        biezacaData = biezacaData.AddDays(7);
    }

    public void PrzesunDoTyluOTydzien()
    {
        biezacaData = biezacaData.AddDays(-7);
    }
}

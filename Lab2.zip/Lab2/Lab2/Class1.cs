﻿using System;

public class Licz
{
    private int value;

    public Licz(int startValue)
    {
        value = startValue;
    }

    public void Dodaj(int number)
    {
        value += number;
    }

    public void Odejmij(int number)
    {
        value -= number;
    }

    // Metoda wypisująca stan obiektu
    public void WypiszStan()
    {
        Console.WriteLine("Wartość: " + value);
    }
}
﻿//ZAD1
//class Program
//{
//    static void Main()
//    {
//        Licz licz1 = new Licz(10);
//        Licz licz2 = new Licz(20);
//        licz1.Dodaj(5);
//        licz2.Odejmij(8);
//        licz1.WypiszStan();
//        licz2.WypiszStan();
//    }
//}

//ZAD2
//class Program
//{
//    static void Main()
//    {
//        int[] liczby = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
//        Sumator sumator = new Sumator(liczby);

//        Console.WriteLine("Suma wszystkich liczb: " + sumator.Suma());
//        Console.WriteLine("Suma liczb podzielnych przez 2: " + sumator.SumaPodziel2());
//        Console.WriteLine("Liczba elementów w tablicy: " + sumator.IleElementów());

//        sumator.WypiszWszystkieElementy();
//        sumator.WypiszElementyZakres(2, 7);
//    }
//}

//ZAD3
//class Program
//{
//    static void Main()
//    {
//        MojaData mojaData = new MojaData();

//        Console.WriteLine(mojaData.OdczytajBiezacaDate());

//        mojaData.PrzesunDoPrzoduOTydzien();
//        Console.WriteLine(mojaData.OdczytajBiezacaDate());

//        mojaData.PrzesunDoTyluOTydzien();
//        Console.WriteLine(mojaData.OdczytajBiezacaDate());
//    }
//}

//ZAD4
class Program
{
    static void Main()
    {
        Liczba mojaLiczba = new Liczba("12345");

        Console.WriteLine("Początkowa wartość liczby:");
        mojaLiczba.WypiszLiczbe();

        Console.WriteLine("Mnożenie przez 5:");
        mojaLiczba.PomnozPrzezInt(5);
        mojaLiczba.WypiszLiczbe();

        int liczbaSilnia = 10;
        Console.WriteLine($"Silnia z {liczbaSilnia} wynosi: {mojaLiczba.Silnia(liczbaSilnia)}");
    }
}

﻿using System;

class Sumator
{
    private int[] Liczby;

    public Sumator(int[] liczby)
    {
        Liczby = liczby;
    }

    public int Suma()
    {
        int suma = 0;
        foreach (int liczba in Liczby)
        {
            suma += liczba;
        }
        return suma;
    }

    public int SumaPodziel2()
    {
        int suma = 0;
        foreach (int liczba in Liczby)
        {
            if (liczba % 2 == 0)
            {
                suma += liczba;
            }
        }
        return suma;
    }

    public int IleElementów()
    {
        return Liczby.Length;
    }

    public void WypiszWszystkieElementy()
    {
        Console.WriteLine("Elementy tablicy:");
        foreach (int liczba in Liczby)
        {
            Console.Write(liczba + " ");
        }
        Console.WriteLine();
    }

    public void WypiszElementyZakres(int lowIndex, int highIndex)
    {
        Console.WriteLine($"Elementy od indeksu {lowIndex} do indeksu {highIndex}:");
        for (int i = Math.Max(lowIndex, 0); i < Math.Min(highIndex + 1, Liczby.Length); i++)
        {
            Console.Write(Liczby[i] + " ");
        }
        Console.WriteLine();
    }
}

﻿using LabPoli;
using System.Drawing;

List<Shape> shapes = new List<Shape>();
Circle circle = new Circle {Name = "Koło", X = 0, Y = 2, Height = 10 };
Rectangle1 rectangle = new Rectangle1 { Name = "Prostokąt", X = 2, Y = 2, Width = 23, Height = 23 };
Triangle triangle = new Triangle { Name = "Trójkąt", X = 2, Y = 34, Width = 8, Height = 5 };

shapes.Add(triangle);
shapes.Add(circle);
shapes.Add(rectangle);
foreach(Shape shape in shapes)
{
    shape.Draw(); Console.WriteLine();
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zad2
{
    internal class Osoba
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public string Pesel { get; set; }

        public void SetFirstName(string name)
        {
            Name = name;
        }
        public void SetLastName(string lastname)
        {
            LastName = lastname;
        }
        public void SetPesel(string pesel)
        {
            Pesel = pesel;
        }
        public int GetAge()
        {
            if (Pesel.Length >= 2 && int.TryParse(Pesel.Substring(0, 2), out int year))
            {
                int currentYear = DateTime.Now.Year;
                int age;

                int century = int.Parse(Pesel[2].ToString());

                if (century < 2)
                {
                    year += 1900;
                }
                else
                {
                    year += 2000;
                }

                age = currentYear - year;
                return age;
            }
            return -1;
        }

        public char GetGender()
        {
            if (Pesel.Length >= 11)
            {
                return Pesel[9] % 2 == 0 ? 'K' : 'M';
            }
            return ' ';
        }
        public virtual string GetEducationInfo()
        {
            int age = GetAge();

            if (age < 0)
            {
                return "Błąd w odczycie wieku";
            }
            else if (age < 14)
            {
                return "Podstawówka";
            }
            else if (age < 18)
            {
                return "Szkoła średnia";
            }
            else
            {
                return "Studia lub poza systemem edukacyjnym";
            }
        }

        public string GetFullName()
        {
            return $"{Name} {LastName}";
        }

        public virtual bool CanGoAloneToHome()
        {
            int age = GetAge();
            bool status;

            if (age < 12)
            {
                return status = false;
            }
            else
            {
                return status = true;
            }
         
        }
    }
}


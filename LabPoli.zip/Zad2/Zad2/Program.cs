﻿using Zad2;

Osoba osoba = new Osoba();
osoba.SetPesel("01300307516");
osoba.SetFirstName("Jakub");
osoba.SetLastName("Sosnowski");


char gender = osoba.GetGender();
int age = osoba.GetAge();
string edu = osoba.GetEducationInfo();
bool home = osoba.CanGoAloneToHome();
string fullName = osoba.GetFullName();

Console.WriteLine($"Płeć: {gender}"); 
Console.WriteLine($"Wiek: {age} lat");
Console.WriteLine($"Edukacja: {edu}");
Console.WriteLine($"Czy może iść do domu samemu: {home}");
Console.WriteLine($"Pełne imie: {fullName}");